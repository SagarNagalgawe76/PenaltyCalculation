import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { PenaltyCalculationRequest, PenaltyCalculationResponse } from './model/penalty-calculation.model';

@Injectable({
  providedIn: 'root'
})
export class PenaltyCalculatorService {
  private apiUrl = 'http://localhost:44319/api/penalty'; 

  constructor(private http: HttpClient) { }

  calculatePenalty(request: PenaltyCalculationRequest): Observable<PenaltyCalculationResponse> {
    return this.http.post<PenaltyCalculationResponse>(`${this.apiUrl}/calculate-penalty`, request);
  }

  getCountries(): Observable<any> {
    return this.http.get(`${this.apiUrl}/countries`);
  }
}

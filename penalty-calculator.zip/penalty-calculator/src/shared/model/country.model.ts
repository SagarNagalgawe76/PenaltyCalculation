export class Country {
    id: number;
    name: string;
    currencyCode: string;
}


export interface PenaltyCalculationRequest {
    checkoutDate: string;
    returnDate: string;
    countryId: number;
  }
  
  export interface PenaltyCalculationResponse {
    calculatedBusinessDays: number;
    formattedPenalty: string;
  }
  
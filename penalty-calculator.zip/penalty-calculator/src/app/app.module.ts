import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { PenaltyCalculatorComponent } from './penalty-calculator/penalty-calculator.component';
import { HttpClientModule } from '@angular/common/http';
import { PenaltyCalculatorService } from 'src/shared/penalty-calculator.service';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    PenaltyCalculatorComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [PenaltyCalculatorService],
  bootstrap: [AppComponent]
})
export class AppModule { }

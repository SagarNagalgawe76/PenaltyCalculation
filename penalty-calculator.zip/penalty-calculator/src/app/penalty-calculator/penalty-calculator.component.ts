import { Component, OnInit } from '@angular/core';
import { PenaltyCalculationRequest, PenaltyCalculationResponse } from 'src/shared/model/penalty-calculation.model';
import { PenaltyCalculatorService } from 'src/shared/penalty-calculator.service';

@Component({
  selector: 'app-penalty-calculator',
  templateUrl: './penalty-calculator.component.html',
  styleUrls: ['./penalty-calculator.component.css'],
})
export class PenaltyCalculatorComponent  implements OnInit {
  checkoutDate: string;
  returnDate: string;
  selectedCountry: number;
  calculatedBusinessDays: number;
  formattedPenalty: string;
  countries: any[]; 

  constructor(private penaltyCalculatorService: PenaltyCalculatorService) {}

  ngOnInit() {
    this.penaltyCalculatorService.getCountries().subscribe(
      (countries: any[]) => {
        this.countries = countries;
      },
      error => {
        console.error('Error fetching countries:', error);
      }
    );
  }

  calculate() {
    const request: PenaltyCalculationRequest = {
      checkoutDate: this.checkoutDate,
      returnDate: this.returnDate,
      countryId: this.selectedCountry
    };

    this.penaltyCalculatorService.calculatePenalty(request).subscribe(
      (result: PenaltyCalculationResponse) => {
        this.calculatedBusinessDays = result.calculatedBusinessDays;
        this.formattedPenalty = result.formattedPenalty;
      },
      error => {
        console.error('Error calculating penalty:', error);
      }
    );
  }
}

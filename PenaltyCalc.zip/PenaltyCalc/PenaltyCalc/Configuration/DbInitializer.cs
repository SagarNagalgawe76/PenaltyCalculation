﻿
using PenaltyCalc.Model;
using System;
using System.Linq;

public static class DbInitializer
{
    public static void Initialize(CalcDbContext context)
    {
        context.Database.EnsureCreated();

        // Seed countries if not exists
        if (!context.Countries.Any())
        {
            var countries = new[]
            {
                new Country { Name = "India", CurrencyCode = "INR" },
                new Country { Name = "Dubai", CurrencyCode = "AED" },
                new Country { Name = "Turkey", CurrencyCode = "TRY" },
                new Country { Name = "Afghanistan", CurrencyCode = "AFN" },
                new Country { Name = "Australia", CurrencyCode = "AUD" },
            };

            context.Countries.AddRange(countries);
            context.SaveChanges();
        }

        // Seed holidays if not exists
        if (!context.Holidays.Any())
        {
            var dubaiCountryId = context.Countries.Single(c => c.Name == "Dubai").Id;
            var turkeyCountryId = context.Countries.Single(c => c.Name == "Turkey").Id;
            var indiaCountryId = context.Countries.Single(c => c.Name == "India").Id;
            var afghanistanCountryId = context.Countries.Single(c => c.Name == "Afghanistan").Id;
            var australiaCountryId = context.Countries.Single(c => c.Name == "Australia").Id;

            var holidays = new[]
            {
                new Holiday { Name = "New Year", Date = new DateTime(2023, 1, 1), CountryId = dubaiCountryId },
                new Holiday { Name = "Christmas", Date = new DateTime(2023, 12, 25), CountryId = turkeyCountryId },
                new Holiday { Name = "Diwali", Date = new DateTime(2023, 11, 19), CountryId = indiaCountryId },
                 new Holiday { Name = "Liberation day", Date = new DateTime(2023, 2, 15), CountryId = indiaCountryId },
                  new Holiday { Name = "National day", Date = new DateTime(2023, 1, 26), CountryId = indiaCountryId },


            };

            context.Holidays.AddRange(holidays);
            context.SaveChanges();
        }
    }
}

﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using PenaltyCalc.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace PenaltyCalc.Configuration
{
    public class DesignTimeDbContextFactory : IDesignTimeDbContextFactory<CalcDbContext>
    {
        public CalcDbContext CreateDbContext(string[] args)
        {
            IConfigurationRoot configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json")
                .Build();

            var builder = new DbContextOptionsBuilder<CalcDbContext>();
            var connectionString = configuration.GetConnectionString("PenaltyCon");
            builder.UseSqlServer(connectionString);

            return new CalcDbContext(builder.Options);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PenaltyCalc.Model;

namespace PenaltyCalc.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PenaltyController : ControllerBase
    {
        private readonly CalcDbContext _context;

        public PenaltyController(CalcDbContext context)
        {
            _context = context;
        }
        [HttpPost("calculate-penalty")]
        public IActionResult CalculatePenalty([FromBody] PenaltyCalcRequest request)
        {
            // business logic to calculate business days and penalty
            var businessDays = CalculateBusinessDays(request.CheckoutDate, request.ReturnDate, request.CountryId);
            var penalty = CalculatePenalty(businessDays, request.CountryId);

            
            var result = new PenaltyCalcResponse
            {
                CalculatedBusinessDays = businessDays,
                FormattedPenalty = $"{penalty:C}" // Format penalty as currency
            };

            return Ok(result);
        }

        private int CalculateBusinessDays(DateTime checkoutDate, DateTime returnDate, int countryId)
        {
            // Fetch holidays for the specified country
            var holidays = _context.Holidays
                .Where(h => h.CountryId == countryId && h.Date >= checkoutDate && h.Date <= returnDate)
                .ToList();

            int businessDays = 0;

            // Loop through each day between checkout and return dates
            for (DateTime date = checkoutDate; date <= returnDate; date = date.AddDays(1))
            {
                // Check if the current day is a weekend (Saturday or Sunday)
                if (date.DayOfWeek != DayOfWeek.Saturday && date.DayOfWeek != DayOfWeek.Sunday)
                {
                    // Check if the current day is not a holiday
                    if (!holidays.Any(h => h.Date.Date == date.Date))
                    {
                        businessDays++;
                    }
                }
            }

            return businessDays;
        }

        private decimal CalculatePenalty(int businessDays, int countryId)
        {
            //penalty is $5.00 per late business day
            const decimal penaltyRate = 5.00m;

            //a fixed number of allowed business days (10 days)
            const int allowedBusinessDays = 10;

            // Calculate the number of late business days
            int lateDays = Math.Max(0, businessDays - allowedBusinessDays);

            // Calculate the penalty amount
            decimal penaltyAmount = lateDays * penaltyRate;

            return penaltyAmount;
        }

    }
}
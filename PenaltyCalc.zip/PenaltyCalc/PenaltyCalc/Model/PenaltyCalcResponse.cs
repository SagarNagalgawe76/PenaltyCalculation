﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PenaltyCalc.Model
{
    public class PenaltyCalcResponse
    {
        public int CalculatedBusinessDays { get; set; }
        public string FormattedPenalty { get; set; }
    }
}
